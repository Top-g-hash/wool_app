const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser'); // Middleware for parsing POST request data
const { WoolProduct } = require('./model/schema'); // Import your WoolProduct model


const app = express();
const port = 3000;

// Middleware to parse JSON and form data
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static('public'));

// Connect to your MongoDB database
mongoose.connect('mongodb://127.0.0.1:27017/woolDB', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Serve the farmer.html page
app.get('/farmer', (req, res) => {
  res.sendFile(__dirname + '/public/views/farmer.html'); // Adjust the path as needed
});

// Serve the businessman.html page
app.get('/businessman', (req, res) => {
  res.sendFile(__dirname + '/public/views/businessman.html'); // Adjust the path as needed
});

// Route for farmers to upload data
app.post('/upload', (req, res) => {
  const breed  = req.body.question1;
  const fineness =  req.body.question2;
  const fiberLength =  req.body.question3;
  const cleanliness =  req.body.question5;
  const color =  req.body.question4;
  
  // Perform data validation (you can add more validation logic here)
  if (!breed || !fineness || !fiberLength || !cleanliness || !color) {
    return res.status(400).send('All fields are required'); // Respond with an error message
  }

  // Create a new wool product directly (without a separate farmer model)
  const newWoolProduct = new WoolProduct({
    breed: breed,
    fineness: fineness,
    fiberLength:fiberLength,
    cleanliness: cleanliness,
    color:color,
    //  totalScore:finalScore,
    //farmerName:
  });

  // Save the wool product to the database
  newWoolProduct
    .save()
    .then(() => {
      res.send('Data uploaded successfully'); // Respond with a success message
    })
    .catch((error) => {
      console.error('Error:', error);
      res.status(500).send('Error uploading data'); // Respond with an error message
    });
});

// Route for businessmen to fetch product data
app.get('/products', (req, res) => {
  // Fetch wool products from the database and send as JSON response
  WoolProduct.find()
    .then((products) => {
      res.json(products);
    })
    .catch((error) => {
      console.error('Error:', error);
      res.status(500).send('Error fetching data'); // Respond with an error message
    });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
