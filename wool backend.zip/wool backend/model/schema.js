const mongoose = require('mongoose');

// Define the wool product schema
const woolProductSchema = new mongoose.Schema({
  breed: {
    type: Number,
    required: true,
  },
  fineness: {
    type: Number,
    required: true,
  },
  fiberLength: {
    type: Number,
    required: true,
  },
  color: {
    type: Number,
    required: true,
  },
  cleanliness: {
    type: Number,
    required: true,
  },
  totalScore:{
    type: Number,
  required: false,
  },
  farmerName: {
    type: String,
  required: false,
  }
  // Add more fields for your product data, such as price, quantity, etc.
});

// Define the WoolProduct model
const WoolProduct = mongoose.model('WoolProduct', woolProductSchema);

module.exports = {
  WoolProduct,
};